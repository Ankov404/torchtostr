Torch To Str Python Package

This free, open-source project aims to simplify arrays of transport of torch tensors over the Internet.

The package includes two functions, one of which converts massive torch tensors into simple ones for transport and text decryption.

The function "tensors_to_string(data: list)" takes an array of torch tensors as arguments and returns text with the transformed torch tensors.

The function "string_to_tensors(data: str)" has the exact opposite effect

Enjoy your use :-)

by Ankov
